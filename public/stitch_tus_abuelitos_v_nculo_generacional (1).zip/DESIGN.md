# Design System Specification: The Digital Heirloom

## 1. Overview & Creative North Star

### Creative North Star: "The Living Archive"
This design system rejects the sterile, grid-locked "tech" aesthetic in favor of a **High-End Editorial** experience. We are not building a utility; we are building a digital heirloom. The aesthetic must feel like a prestige lifestyle journal—warm, authoritative, and deeply human.

To move beyond the "template" look, we employ **Intentional Asymmetry**. Elements should not always align to a rigid 12-column grid; use generous, staggered white space and overlapping components (e.g., an image overlapping a background container) to create a sense of movement and organic growth. The goal is to make the user feel like they are leafing through a beautifully curated collection of stories.

---

## 2. Colors: Tonal Depth & Soul

Our palette is rooted in the earth and the sky of Ciudad Juárez. We prioritize warmth over clinical precision.

### Core Palette
- **Primary (#9b3f25 - Terracotta):** Represents the wisdom of the elders and the warmth of the sun. Used for primary actions and signature moments.
- **Secondary (#4e6073 - Slate Blue):** Provides a stable, professional anchor. Use this for navigation and secondary UI elements to establish trust.
- **Tertiary (#476500 - Moss Green):** Dedicated to the "Gardens" program and themes of growth and hope.
- **Neutral Surface (#fbf9f5):** A soft, "paper-like" white that prevents eye strain and feels more premium than a pure `#ffffff`.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections or cards. 
Boundaries must be created through **Background Color Shifts**. For example, a `surface-container-low` component should sit on a `surface` background. If you need more definition, use a tonal transition, never a hard line.

### Glassmorphism & Signature Gradients
- **Glassmorphism:** Use semi-transparent surface colors (e.g., `on-surface-variant` at 5% opacity) with a `backdrop-blur` of 20px for floating navigation or overlay cards. This creates a "frosted glass" effect that adds high-end dimension.
- **Signature Gradients:** For Hero sections or primary CTAs, use a subtle linear gradient from `primary` (#9b3f25) to `primary-container` (#bb563b). This adds "soul" and prevents the flatness associated with generic UI kits.

---

## 3. Typography: Tradition Meets Clarity

We utilize a high-contrast scale to emphasize the "Editorial" feel.

- **Display & Headlines (Noto Serif):** This characterful serif conveys tradition, history, and wisdom. Use `display-lg` (3.5rem) for hero statements to create an immediate emotional impact.
- **Body & Labels (Lexend):** Chosen for its exceptional legibility, especially for elderly users. The geometric clarity of Lexend balances the heritage of Noto Serif.
- **Hierarchy Logic:** Always lead with Noto Serif for storytelling and Lexend for functional guidance.

| Level | Token | Font | Size | Weight |
| :--- | :--- | :--- | :--- | :--- |
| Display | display-lg | Noto Serif | 3.5rem | 700 |
| Headline | headline-md | Noto Serif | 1.75rem | 600 |
| Title | title-md | Lexend | 1.125rem | 500 |
| Body | body-lg | Lexend | 1.0rem | 400 |
| Label | label-md | Lexend | 0.75rem | 500 |

---

## 4. Elevation & Depth: Tonal Layering

We achieve hierarchy through physical stacking rather than artificial shadows.

- **The Layering Principle:** Use the `surface-container` tiers to nest content. 
    - *Background:* `surface` (#fbf9f5)
    - *Main Section:* `surface-container-low` (#f5f3ef)
    - *Feature Card:* `surface-container-lowest` (#ffffff)
- **Ambient Shadows:** Shadows should be used sparingly. When required, use a large blur (30px+) with low opacity (4-6%). Use a tinted shadow—instead of black, use a semi-transparent version of `on-surface` (#1b1c1a) to maintain a natural, ambient light feel.
- **The "Ghost Border" Fallback:** If a border is essential for accessibility, use the `outline-variant` (#e0c0b2) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons
- **Primary:** Pill-shaped (`rounded-full`), `primary` background, `on-primary` text. No shadow.
- **Secondary:** Pill-shaped, `secondary-container` background, `on-secondary-container` text.
- **Tertiary:** Text-only, using `title-sm` in `primary` color. Use for low-emphasis actions like "Learn More."

### The Program Cards
For the four main programs (Mentors, Letters, Gardens, Digital Archive), use `surface-container-high`. 
- **Layout:** Asymmetric. The icon (Line Art) should be placed in the top-right, partially bleeding off the card edge.
- **Interaction:** On hover, the card should transition to `surface-container-highest` with a subtle 2px vertical lift.

### Inputs & Fields
- **Style:** Underline-only or subtle `surface-variant` backgrounds. 
- **Rounding:** `rounded-sm` (0.25rem) to maintain a sense of formal structure amidst the softer pill-shaped buttons.

### Lists
- **Rule:** Forbid divider lines. 
- **Separation:** Use `1.5rem` (Spacing XL) of vertical white space or alternating backgrounds (`surface` to `surface-container-low`) to separate list items.

---

## 6. Do’s and Don’ts

### Do
- **Do** use large, high-quality photography with warm, film-like grain.
- **Do** allow text to overlap images slightly to create an "Editorial" layout.
- **Do** use `rounded-xl` (1.5rem) for large containers to evoke a friendly, approachable mood.
- **Do** ensure all interactive elements have a minimum touch target of 48px for elderly accessibility.

### Don't
- **Don't** use 100% black text. Always use `on-surface` (#1b1c1a) for a softer, more premium contrast.
- **Don't** use standard "Drop Shadows" from a UI kit. They look cheap and break the "paper" metaphor.
- **Don't** clutter the screen. If a page feels full, increase the white space by 20%.
- **Don't** use sharp 90-degree corners; they feel aggressive. Stick to the `roundedness` scale provided.